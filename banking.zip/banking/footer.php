<div id="footer-container">
        <div id="footer" >
            <div id="finalized">
                © 2017 Kins Bank
                <span class="push-sides">&nbsp;</span>
                Member FDIC | Equal Housing Lender
                <img src="images/eoe_logo.gif" alt="">
                <span class="push-sides">&nbsp;</span>
                <a href="https://online.woodforest.com/interface?style=mobile_rich">Mobile Web Site</a>
            </div>
            <div id="fdic-news">
                FDIC NEWS: 
                <a href="https://www5.fdic.gov/edie/" class="speed_bump">Learn More</a>
            </div>
        </div>
    </div>
</div>
           <script src="js/jquery.min.js"></script>
		
		<!-- Latest compiled and minified javascript -->
		<script src="js/bootstrap.min.js"></script>
</body>

</html>