<?php require_once('header.php')?>
<div id="content-container" style=" background-color: green;">
     <div id="page-content" class="offset-content"  >
            
    

	<div class="container" style=" background-color: white;">
		<div style="float: right; width: 900px; margin-bottom: 15px;">
		<div class= "image">
	
        <img src="images/business.jpg" class="img-thumbnail" alt="Responsive image" style="width: 960px; height: 360px;">
		</div>
					
				<div>
				<h1 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
         BUSINESS BANKING
        </h1><p style="text-align: center; color: #333333; font-family: sans-serif; font-size: 1.4em; font-weight: 400;">
         We're proud to have been listed one of the best bank by Moneyfacts. We support small to medium sized start-up and established businesses with straightforward banking needs and up to two directors, owners (shareholders) or partners. We offer current accounts, savings accounts, card acceptance services, insurance and loans of up to £25,000. If you have a medium to large sized business and would like a relationship managed service or have comprehensive banking, international business or larger lending needs, please visit Corporate & Commercial Banking.

Your money, your way. Take a closer look at Online, Mobile and Telephone Business Banking to see how it works and how you can stay in control of your money.

We have over 200 free sector specific guides to help you learn more about your industry and starting and running your business.

We introduce you to our Business Banking to help protect your business with a choice of insurance products and services to meet your business needs.

Simple straightforward business current accounts for start-ups and established businesses.</p></div><br>
		 <h2 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
          Products
        </h2>
		<div class="row">
         <div class="col-md-7">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Checking Products</h1>
			<p>We offer business checking accounts designed to meet your business needs.</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
         
         <div class="col-md-5">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Loans Products</h1>
			<p>Help your business succeed using our competitive commercial lending products.</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
      </div>
	  <br>
	  <h2 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
          Services
        </h2>
	  <div class="row">
         <div class="col-md-3">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Cash Management</h1>
			<p>Cash Management solutions designed with your company’s unique needs in mind</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
         <div class="col-md-3">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Investments</h1>
			<p>Kins Financial Services  addresses the financial needs of professionals, business owners, and executives</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
         <div class="col-md-3">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Merchant Services</h1>
			<p>Work with one of our specialists to find a unique processing solution to fit your payment solution needs.</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
		 <div class="col-md-3">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Federal Tax Payments</h1>
			<p>Pay your federal taxes electronically using the Electronic Federal Tax Payment System.</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
      </div>
	 
<!---- jub---->


<!---- jub---->
</div>
		
		</div>
     </div>
   </div>

<?php require_once('footer.php')?>