<?php require_once('header.php')?>
 <div id="content-container" style=" background-color: green;">
     <div id="page-content" class="offset-content"  >
            
    

	<div class="container" style=" background-color: white;">
		<div style="float: right; width: 900px; margin-bottom: 15px;">
    
					<div id="my-slider" class="carousel slide" data-ride="carousel">
					   
					   <!-- indicators dot nav -->
					        <ol class="carousel-indicators">
							    <li data-target="#my-slider" data-slide-to="0" class="active"></li>
								<li data-target="#my-slider" data-slide-to="1"></li>
								<li data-target="#my-slider" data-slide-to="2"></li>
								<li data-target="#my-slider" data-slide-to="3"></li>
							</ol>
					   
					   <!-- wrappers for slides -->
					   <div class="carousel-inner" role="listbox">
					        <div class="item active">
							    <img src="images/01.jpg" alt="fruits">
							</div>
							<div class="item">
							    <img src="images/02.jpg" alt="fruits">								
							</div>
							<div class="item">
							    <img src="images/03.jpg" alt="fruits">								
							</div>
							<div class="item">
							    <img src="images/04.jpg" alt="fruits">								
							</div>
					   </div>
					   <!-- controls or next and prev buttons -->
					   <a class="left carousel-control" href="#my-slider" role="button" data-slide="prev">
					        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
					   </a>
					   <a class="right carousel-control" href="#my-slider" role="button" data-slide="next">
					        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
					   </a>
					</div>
				<div>
				<h1 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
          Kins Bank Commitment
        </h1><p style="text-align: center; color: #333333; font-family: sans-serif; font-size: 1.4em; font-weight: 400;">
          Kins Bank is a community bank built upon the needs of the customers we serve. We are committed to earning customer loyalty by offering the highest level of customer service as well as competitive products and services by employees who are fair, responsive, and professional.
        </p></div><br>
		<div class="row">
         <div class="col-md-4">
           <h1 style="color: #333333; font-size: 1.9em; font-weight: 400;"><span class="badge" style="background:#FFF;"><img src="images/personalBanking.png"></span>Personal Banking</h1>
            <p style="color: #333333; font-family: sans-serif; font-size: 15px; font-weight: 400;">Checking & savings accounts, online & mobile banking, debit cards, and more. Our products and services are designed to fit your lifestyle.</p>
            <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
         </div>
         <div class="col-md-4">
          <h1 style="color: #333333; font-size: 1.9em; font-weight: 400;"><span class="badge" style="background:#FFF;"><img src="images/businessBanking.png"></span>Business Banking</h1>
          <p style="color: #333333; font-family: sans-serif; font-size: 15px; font-weight: 400;">Business checking, business loans, merchant services, treasury management, and more. See how we can help grow your business.</p>
          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
         </div>
         <div class="col-md-4">
          <h1 style="color: #333333; font-size: 1.9em; font-weight: 400;"><span class="badge" style="background:#FFF;"><img src="images/LineOfCredit.png"></span>Loans</h1>
          <p style="color: #333333; font-family: sans-serif; font-size: 1.2em; font-weight: 400;">Revolving lines of credit auto loans, home improvement loans, mortgages, and more. We want to help finance your needs.</p>
          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
         </div>
      </div><br>
	  <h1 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
          Today Rate's
        </h1>
<table class="table table-bordered">
    <thead>
      <tr>
        <th>Advantage Account</th>
        <th>Tax-Free Advantage Account</th>
        <th>$US Advantage Account</th>
		<th>5-year GIC</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>0.90 %</td>
        <td>0.90 %</td>
        <td>0.25 %</td>
		<td>1.80 %</td>
      </tr>
</table>
<!---- jub---->
<h1 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
          With Us
        </h1>
 <div class="row">
   <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/customer.jpg" alt="Pulpit Rock" style="width:300px;height:150px">
	  <p>We make you feel you are the only customer we got,</p>
	  </div>	      
  </div>
   <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/card2.jpg" alt="Pulpit Rock" style="width:300px;height:150px">
	  <p>Either home, or away. We priortise your security above any other thing.</p>
	  </div>	      
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/card.jpg" alt="Pulpit Rock" style="width:300px;height:150px">
	  <p>With our card, we give you the flexibility of spending at your own wish.</p>
	  </div>	      
  </div>
</div>
<br>
<div class="row">
   <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/care.jpg" alt="Pulpit Rock" style="width:300px;height:150px">
	  <p>And when the going gets wrong, we will still be here for you.</p>
	  </div>	      
  </div>
   <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/download.jpg" alt="Pulpit Rock" style="width:300px;height:150px">
	  <p>We won't just sit, We go with you anywhere you are.</p>
	  </div>	      
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <img src="images/location.png" alt="Pulpit Rock" style="width:300px;height:150px">
	  <p>With you by our side, we will love to bank the world.</p>
	  </div>	      
  </div>
</div>
<!---- jub---->
</div>
		
		</div>
     </div>
   </div>

<?php require_once('footer.php')?>