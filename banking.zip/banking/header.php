<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="shortcut icon" href="images/favicon.jpg" type="image/x-icon">
<title>
	KINS BANK
</title>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css">
<link href="css/common.css" rel="stylesheet" type="text/css">
<link href="css/common_print.css" rel="stylesheet" type="text/css" media="print">
<script language="javascript" type="text/javascript" src="js/jQuery.js"></script>
<script language="javascript" type="text/javascript" src="js/jQuery-ui.js"></script>
<script>
  window.onload = setInterval(clock,1000);

    function clock()
    {
	  var d = new Date();
	  
	  var date = d.getDate();
	  
	  var month = d.getMonth();
	  var montharr =["Jan","Feb","Mar","April","May","June","July","Aug","Sep","Oct","Nov","Dec"];
	  month=montharr[month];
	  
	  var year = d.getFullYear();
	  
	  var day = d.getDay();
	  var dayarr =["Sun","Mon","Tues","Wed","Thurs","Fri","Sat"];
	  day=dayarr[day];
	  
	  var hour =d.getHours();
      var min = d.getMinutes();
	  var sec = d.getSeconds();
	
	  document.getElementById("date").innerHTML=day+" "+date+" "+month+" "+year+", "+hour+":"+min+":"+sec;
    }
</script>
</head>

<body lang="en" onload="startTime()">
	<div id="header-container">
			<div id="header">
				<div id="header-opts">
					<a target="_blank" class="first" href="#">Locations</a>
					<a target="_blank" href="contact">Contact Us</a>
					<a target="_blank" href="privacy">Privacy</a>
					<a target="_blank" href="contact">Help</a>
					<a target="_blank"><img src="images/canadaflag.jpg" alt="country"></a>
                
				</div>
            <a target="_top" href="index"><img id="wfLogo" src="images/logo.jpg" alt=""></a>
        </div>
    </div>
    <div id="navigation-container">
        <div id="navigation" class="menu">
            <ul>
                <li class="top-nav"><a href="personal">Personal Banking</a></li>
                <li class="top-nav"><a href="Business-Banking">Business Banking</a></li>
                <li class="top-nav "><a href="About-Us">About Us</a></li>
				<li class="top-nav "><a href="login">login</a></li>
			</ul>
        </div>
    </div>
	<div id="page-overview-container" class="">
        <div id="page-overview">
            
    
    <h1><div id="date"></div></h1>

        </div>
        <div class="clear"></div>
    </div>