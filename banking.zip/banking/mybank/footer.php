<div id="footer-container">
        <div id="footer" >
            <div id="finalized">
                © 2017 Kins Bank
                <span class="push-sides">&nbsp;</span>
                Member CDIC | Equal Housing Lender
                <img src="../images/eoe_logo.gif" alt="">
                <span class="push-sides">&nbsp;</span>
                <a href="#">Mobile Web Site</a>
            </div>
            <div id="fdic-news">
                CDIC NEWS: 
                <a href="#" class="speed_bump">Learn More</a>
            </div>
        </div>
    </div>
</div>
           <script src="../js/jquery.min.js"></script>
		
		<!-- Latest compiled and minified javascript -->
		<script src="../js/bootstrap.min.js"></script>
</body>

</html>