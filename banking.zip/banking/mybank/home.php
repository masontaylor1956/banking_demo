<?php
//include auth.php file on all secure pages
include("../auth.php");

?>
<?php require_once('header.php')?>
<div id="content-container">
        <div class="row">		
		<div class="col-md-3 sidebar-offcanvas" id="sidebar">
		<h1>Account Summary</h1>
		 <div class="list-group">
            <a href="#" class="list-group-item active">Link</a>
            <a href="#" class="list-group-item">Link</a>
            <a href="#" class="list-group-item">Link</a>
            <a href="#" class="list-group-item">Link</a>
            <a href="#" class="list-group-item">Link</a>
            <a href="#" class="list-group-item">Link</a>
            <a href="#" class="list-group-item">Link</a>
            <a href="#" class="list-group-item">Link</a>
            <a href="#" class="list-group-item">Link</a>
            <a href="#" class="list-group-item">Link</a>
        </div><!--/.sidebar-offcanvas-->
      </div><!-
		</div>
		<div class="col-md-9">
		</div>
</div>
<?php require_once('footer.php')?>