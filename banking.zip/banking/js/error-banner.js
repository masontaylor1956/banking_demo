$(function() {
  $('.login-error-banner-close').click(function() {
    $('.login-error-banner').slideUp();
  });
});
