<?php
//include auth.php file on all secure pages
require('db.php');
include("auth.php");
$username = $_SESSION['username'];
?>
<?php require_once('header.php')?>

<p>Welcome <?php echo $username; ?>!</p>
 <div id="content-container">
        <div id="page-content" class="offset-content">
            
    

<div class="container">
    <div style="float: right; width: 750px; margin-bottom: 15px;">


<div class="advert">
<div class="advert">
    <div style="border: 1px solid #AAA; padding: 5px; font-size: 1.1em; background-color: #FAFAEA;">We need you to verify if this is you, KIndly answer the security question</div>
	<div style="padding: 5px;border:1px solid #AAA"><p>
       <?php
	   $query= "SELECT * FROM `users` WHERE username='$username'";
	   $result = mysqli_query($con,$query) or die(mysql_error());
	   if ($result->num_rows > 0) {
    
     // output data of each row
     while($row = $result->fetch_assoc()) {
         $security =  $row["security_question"];
}
   
} else {
     echo "";
}
?>
<?php
if (isset($_POST['answer'])){
    $answer = stripslashes($_REQUEST['answer']);
	$answer = mysqli_real_escape_string($con,$answer);
    $query = "SELECT answer FROM `users` WHERE username='$username'";
	$result = mysqli_query($con,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
        if($rows==1){
            // Redirect user to index.php
	    header("Location: mybank/home");
    }
      else
      {
    echo "<script type='text/javascript'>alert('Incorrect Answer!')</script>";
    }
    }
?>
 <form action="secure" method="POST" name="secure">
        <div class="push-down">
            <div style="width: 180px;">
              <span class="input-header">Question:</span>
            </div>
            <input type="text" name="question" class="shadow" value="<?php echo $security;?>" maxlength="320" readonly>
        </div>
        <div class="push-down">
            <div class="input-header">Answer:</div>
            <div><input type="text" name="answer" class="shadow" style="width: 175px;"  maxlength="320" autocomplete="off" required>
			</div>
        </div>
        <input type="submit" id="challenge-commit" name="submit" value="answer" class="button" tabindex="3">
        <div style="margin-top: 3px;"></div>
    </form>
	   </div></div></div>
</div>
    </div>


</div>
        </div>
    </div>
<?php require_once('footer.php')?>