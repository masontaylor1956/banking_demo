
<div id="footer-container">
        <div id="footer">
            <div id="finalized">
                © 2017 Woodforest National Bank
                <span class="push-sides">&nbsp;</span>
                Member FDIC | Equal Housing Lender
                <img src="images/eoe_logo.gif" alt="">
                <span class="push-sides">&nbsp;</span>
                <a href="https://online.woodforest.com/interface?style=mobile_rich">Mobile Web Site</a>
            </div>
            <div id="fdic-news">
                FDIC NEWS: 
                <a href="https://www5.fdic.gov/edie/" class="speed_bump">Learn More</a>
            </div>
        </div>
    </div>
</div>
</body></html>