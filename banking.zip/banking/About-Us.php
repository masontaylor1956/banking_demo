<?php require_once('header.php')?>
<div id="content-container" style=" background-color: green;">
     <div id="page-content" class="offset-content"  >
            
    

	<div class="container" style=" background-color: white;">
		<div style="float: right; width: 900px; margin-bottom: 15px;">
		<div class= "image">
	
        <img src="images/business.jpg" class="img-thumbnail" alt="Responsive image" style="width: 960px; height: 360px;">
		</div>
					
				<div>
				<h1 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
         About Us
        </h1><p style="text-align: center; color: #333333; font-family: sans-serif; font-size: 1.4em; font-weight: 400;">
		Kins Bank is a state chartered stock savings bank that was incorporated and officially established on May 25, 1889. The founders’ objectives and vision established the basic premise that has guided the operations of Kins Bank throughout the years: to provide superior customer service and support of the communities it serves.

We are proud to have directorship of local business owners and professionals. It has always been our focus as a community bank to provide the best banking services available. We have historically selected our banking locations by identifying areas that did not have a financial institution to meet the needs of the community.

Our group of banks has grown since our inception in 1979. We currently have a staff of approximately 80-employees. We thrive on building relationships with our customers and believe our slogan, "Your Financial Interest is what we work up to", promotes our continuing mission and commitment to providing true “Community Banking”.

We have customer friendly lobby and drive-up hours. All our locations have safe deposit boxes. Many of our employees have worked for The State Bank Group for 10-years or more. All our loan officers have real lending authority and this allows you to discuss your loan needs with a decision maker. This makes your experience both personal and efficient.

To our customers who are visiting our web site, “Thank You Very Much”. If you are not currently a customer, we invite you to “Bank Where You’re Known”.
		</p></div><br>
		

	 
<!---- jub---->


<!---- jub---->
</div>
		
		</div>
     </div>
   </div>

<?php require_once('footer.php')?>