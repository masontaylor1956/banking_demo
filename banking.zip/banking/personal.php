<?php require_once('header.php')?>
<div id="content-container" style=" background-color: green;">
     <div id="page-content" class="offset-content"  >
            
    

	<div class="container" style=" background-color: white;">
		<div style="float: right; width: 900px; margin-bottom: 15px;">
		<div class= "image">
	
        <img src="images/personal.jpg" class="img-thumbnail" alt="Responsive image" style="width: 960px; height: 360px;">
		</div>
					
				<div>
				<h1 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
         PERSONAL BANKING
        </h1><p style="text-align: center; color: #333333; font-family: sans-serif; font-size: 1.4em; font-weight: 400;">
         A dedicated team, creating enduring financial advantage for high net worth clients.

Personalised service with your own relationship manager with an array of financial solutions.

Advice and tools delivering tailored plans to help achieve your financial goals.

As you go through life, your financial needs and priorities change. We have world-class banking products and services to support you at every stage.

A relationship that is packed with services & product offering and recognizes your loyalty too - the more you bank, the more rewards you receive</p></div><br>
		 <h2 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
          Products
        </h2>
		<div class="row">
         <div class="col-md-4">
           <div class="thumbnail">
		   <h1>Checking</h1>
			<p>We have several checking account options. Find out which one is right for you.</p>
			<p><button type="button" class="btn btn-success">checking product</button></p>
		   </div>
         </div>
         <div class="col-md-4">
           <div class="thumbnail">
		   <h1>Savings</h1>
			<p>Select from several savings options to meet your savings goals.</p>
			<p><button type="button" class="btn btn-success">saving product</button></p>
		   </div>
         </div>
         <div class="col-md-4">
           <div class="thumbnail">
		   <h1>Loans</h1>
			<p>Check out our competitive consumer loan products designed to meet your needs.</p>
			<p><button type="button" class="btn btn-success">Loans</button></p>
		   </div>
         </div>
      </div>
	  <br>
	  <h2 style="text-align: center; color: green; font-size: 2.5em; font-weight: 400;">
          Services
        </h2>
	  <div class="row">
         <div class="col-md-4">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Online Banking</h1>
			<p>Online Banking gives instant access to your accounts from the convenience of home, work, or wherever an Internet connection is available.</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
         <div class="col-md-4">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Mobile Banking</h1>
			<p>Bank remotely through our mobile banking website and our downloadable applications for iPhone®, iPod®, iPad® or AndroidT</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
         <div class="col-md-4">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Overdraft Solutions</h1>
			<p>We offer overdraft solutions to assist in managing your account while helping control costs.</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
      </div>
	  <br>
	  <div class="row">
         <div class="col-md-4">
           <div class="thumbnail" style="background: #eeeeee;" >
		   <h1>Financial Services</h1>
			<p>Kins Financial Services addresses the financial needs of professionals, business owners, and executives.</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
         <div class="col-md-4">
           <div class="thumbnail" style="background: #eeeeee;">
		   <h1>Card Services</h1>
			<p>Our card services include the kins Debit Card.</p>
			<p><button type="button" class="btn btn-default">learn more >></button></p>
		   </div>
         </div>
        
      </div>
<!---- jub---->


<!---- jub---->
</div>
		
		</div>
     </div>
   </div>

<?php require_once('footer.php')?>