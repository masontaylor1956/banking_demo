<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<title>
	privacy
</title>
<link rel="stylesheet" href="css/privacy.css">
</head>
<body lang="en">
<div class="policy">
    <div class="page"><table class="rev"><td class="c0">Rev. April 2016</td></table><table class="header"><td class="title">Facts</td><td class="c0">What does Kins bank do with your personal information?</td></table><table class="main-section"><td class="title">Why?</td><td class="c0">
            Financial companies choose how they share your personal information. Federal law gives consumers the
            right to limit some but not all sharing. Federal law also requires us to tell you how we collect, share, and
            protect your personal information. Please read this notice carefully to understand what we do.
          </td></table><table class="main-section"><td class="title">What?</td><td class="c0">
            The types of personal information we collect and share depend on the product or service you have with us. 
            This information can include:
            <ul>
              <li>Social Security number and income</li>
              <li>Account balances and payment history</li>
              <li>Credit history and checking account information</li>
            </ul>
            When you are <i>no longer</i> our customer, we continue to share your information as described in this notice.
          </td></table><table class="main-section"><td class="title">How?</td><td class="c0">
            All financial companies need to share customers’ personal information to run their everyday business. In
            the section below, we list the reasons financial companies can share their customers’ personal information;
            the reasons we choose to share; and whether you can limit this sharing.
          </td></table><table class="three-column"><tr><th class="c0">Reasons we can share your personal information</th><th class="c1">Does Kins share?</th><th class="c2">Can you limit this sharing?</th></tr><tr><td class="c0">
              <b>For our everyday business purposes-</b><br />
              such  as  to  process  your  transactions,  maintain  your account(s), respond to court orders and legal investigations, or report to credit bureaus
              </td><td class="c1">Yes</td><td class="c2">No</td></tr><tr><td class="c0">
              <b>For our marketing purposes-</b><br />
              to offer our products and services to you
              </td><td class="c1">Yes</td><td class="c2">No</td></tr><tr><td class="c0"><b>For joint marketing with other financial companies</b></td><td class="c1">Yes</td><td class="c2">No</td></tr><tr><td class="c0">
              <b>For our affiliates&#39; everyday business purposes-</b><br />
              information about your transactions and experiences
              </td><td class="c1">Yes</td><td class="c2">No</td></tr><tr><td class="c0">
              <b>For our affiliates&#39; everyday business purposes-</b><br />
              information about your creditworthiness
              </td><td class="c1">No</td><td class="c2">We don&#39;t share</td></tr><tr><td class="c0"><b>For our affiliates to market to you</b></td><td class="c1">No</td><td class="c2">We don&#39;t share</td></tr><tr><td class="c0"><b>For nonaffiliates to market to you</b></td><td class="c1">No</td><td class="c2">We don&#39;t share</td></tr></table><table class="main-section"><td class="title">Questions?</td><td class="c0">Call toll-free 1-877-968-7962 or go to https://www.Kins.com</td></table></div><div class="page"><table class="two-column"><tr><th class="c0">Who we are</th><th class="c1"></th></tr><tr><td class="c0">Who is providing this notice?</td><td class="c1">Kins bank (&quot;Kins&quot;)</td></tr></table><table class="two-column"><tr><th class="c0">What we do</th><th class="c1"></th></tr><tr><td class="c0">How does Kins protect my personal information?</td><td class="c1">
              To  protect  your  personal  information  from  unauthorized  access  and  use,  we  use 
              security measures that comply with federal law. These measures include computer 
              safeguards and secured files and buildings.
              <p>
                We also limit access by our employees to information that we believe is reasonably 
                necessary to maintain your accounts, complete a transaction that you authorized, or 
                otherwise meet your needs.
              </p>
              </td></tr><tr><td class="c0">How does Kins collect my personal information?</td><td class="c1">
              We collect your personal information, for example, when you
              <ul>
                <li>open an account or deposit money</li>
                <li>pay your bills or apply for a loan</li>
                <li>use your credit or debit card</li>
              </ul>
              We  also  collect  your  personal  information  from  others,  such  as  credit  bureaus, affiliates, or other companies.
              </td></tr><tr><td class="c0">Why can&#39;t I limit all sharing?</td><td class="c1">
              Federal law gives you the right to limit only
              <ul>
                <li>sharing for affiliates’ everyday business purposes–information about your creditworthiness</li>
                <li>affiliates from using your information to market to you</li>
                <li>sharing for nonaffiliates to market to you</li>
              </ul>
              State laws and individual companies may gvie you additional rights to limit sharing.
              </td></tr></table><table class="two-column"><tr><th class="c0">Definitions</th><th class="c1"></th></tr><tr><td class="c0">Affiliates</td><td class="c1">
              Companies related by common ownership or control. They can be financial and nonfinancial companies.<br /><br />
              
              Our affiliates include financial companies such as
              <ul>
                <li>investment companies</li>
                <li>insurance companies</li>
              </ul>
              </td></tr><tr><td class="c0">Nonaffiliates</td><td class="c1">
              Companies not related by common ownership or control. They can be financial and nonfinancial companies.
              <p>
                We don&#39;t share with nonaffiliates so that they can market to you.
              </p>
              </td></tr><tr><td class="c0">Joint Marketing</td><td class="c1">
               A formal agreement between nonaffiliated financial companies that together market financial products or services to you.
              <p>Our joint marketing partners include financial services companies.</p>
              </td></tr></table></div>
    <table class="footer">
        <tr>
            <td class="c0">
                <div style="font-size: 9px;">Member</div>
                <div style="font-size: 18px;">FDIC</div>
            </td>
            <td class="c1">
                <img src="/images/logo_bw.png" />
                <div class="slogan">Banking your way... <i>EVERY DAY AND NIGHT!</i><sup>&reg;</sup></div>
                <div class="link"><a href="https://www.Kins.com/">www.Kins.com</a></div>
                <div class="eoe">Kins is an Equal Opportunity Employer.</div>
            </td>
            <td class="c2">
                <img src="/images/ehl.png" />
            </td>
        </tr>
    </table>
</div>
</body>
</html>